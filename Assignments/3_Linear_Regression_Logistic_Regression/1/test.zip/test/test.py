import json 
import pandas as pd
import numpy as np
from sklearn.metrics import f1_score
import joblib





def get_result():

    
    ans = pd.read_csv('test/ans.csv')
    output  = pd.read_csv('submission.csv')
    model = joblib.load('model')

    score = 0
    try :
        if not 'LogisticRegression' in type(model).__name__ :
            description = 'مدلی که استفاده کرده‌اید، رگرسیون لجستیک نبوده است.' + '\n' + 'مدل شما = ' + str(model)
            return {
                "name" : "test macro_f1" ,
                "description" : description ,
                "grade_test_100" : 0
            }
    except :
        description = 'در بارگزاری مدل مشکلی آمده است. ممکن است مدل را ذخیره نکرده باشید یا از سایکیت‌لرن استفاده نکرده باشید یا حتی مدل نامطلوبی استفاده کرده باشید.'
        return {
            "name": "test macro_f1",
            "description": description,
            "grade_test_100": 0
        }


    if len(output) != len(ans) : 
        description = 'تعداد سطرهای فایل ارسالی شما، با آنچه در صورت مسئله توضیح داده شد، مغایرت دارد.' + '\n' + \
            'تعداد سطر مورد انتظار برای فایل ارسالی برابر است با :' + '\n' + str(len(ans)) + '\n' + \
                'تعداد سطرهای فایلی که ارسال کرده اید برابر است با :' + '\n' + str(len(output))
        return {
                'name': 'test macro_f1',
                'grade_test_100': score,
                'description': description
                }

    if 'prediction' not in output.columns : 
        description = 'ستونی با اسم' + '\n' + 'prediction' + '\n' + 'در فایل ارسالی شما یافت نشد. ستون‌های فایل ارسالی شما برابر است با :' \
            + '\n' + str(output.columns)

        return {
            'name': 'test macro_f1',
            'grade_test_100': score,
            'description': description
            }

        
    nas = output.isna().sum()['prediction']
    if nas > 0 :
        description = 'در فایل ارسالی شما، مقادیر نال وجود دارد.'
        return {
            'name': 'test macro_f1',
            'grade_test_100': score,
            'description': description
            }

    else :
        final = ans.join(output, lsuffix='_ans')

        description = 'macro_f1_score * 100'
        score = f1_score(final['prediction_ans'], final['prediction'], average='macro') * 100
        

    
    return {
        'name': 'test macro_f1',
        'grade_test_100': score,
        'description': description
    }
    


def main():
    print(
        json.dumps([
            get_result()
        ])
    )


if __name__ == '__main__':
    main()
